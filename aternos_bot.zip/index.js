const mineflayer = require('mineflayer');

function createBot() {
  const bot = mineflayer.createBot({
    host: 'your-server.aternos.me', // ضع رابط سيرفرك هنا
    port: 25565,
    username: 'yourEmail@gmail.com', // بريد حساب ماينكرافت
    password: 'yourPassword', // كلمة المرور
    auth: 'microsoft' // استخدم 'mojang' إذا كان الحساب قديم
  });

  bot.on('spawn', () => {
    console.log('دخل البوت السيرفر!');
    setInterval(() => {
      bot.setControlState('forward', true);
      setTimeout(() => bot.setControlState('forward', false), 1000);
    }, 60000); // يتحرك كل دقيقة
  });

  bot.on('end', () => {
    console.log('تم طرد البوت، إعادة الاتصال بعد 5 ثواني...');
    setTimeout(createBot, 5000);
  });

  bot.on('error', err => console.error('خطأ:', err));
}

createBot();
